
export const TRIAL_DAYS = 3;